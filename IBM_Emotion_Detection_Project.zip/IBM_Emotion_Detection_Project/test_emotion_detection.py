"""Unit tests for EmotionDetection; HTTP calls are mocked for repeatability."""

import unittest
from unittest.mock import Mock, patch

import requests

from EmotionDetection import emotion_detector


class TestEmotionDetection(unittest.TestCase):
    """Validate output formatting, errors, and Watson request integration."""

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_joy(self, mock_post):
        """Joy should be selected for a joyful statement."""
        mock_post.return_value = self._response({
            "anger": 0.01, "disgust": 0.02, "fear": 0.03,
            "joy": 0.91, "sadness": 0.03,
        })
        result = emotion_detector("I am glad this works.")
        self.assertEqual(result["dominant_emotion"], "joy")
        self.assertAlmostEqual(result["joy"], 0.91)
        self.assertEqual(len(result), 6)
        self.assertEqual(
            mock_post.call_args.kwargs["json"],
            {"raw_document": {"text": "I am glad this works."}},
        )

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_anger(self, mock_post):
        """Anger should be selected for a mock angry sentence."""
        mock_post.return_value = self._response({
            "anger": 0.91, "disgust": 0.02, "fear": 0.03,
            "joy": 0.01, "sadness": 0.03,
        })
        self.assertEqual(emotion_detector("This is unacceptable!")["dominant_emotion"], "anger")

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_disgust(self, mock_post):
        """Disgust should be selected when it has the highest score."""
        mock_post.return_value = self._response({
            "anger": 0.11, "disgust": 0.70, "fear": 0.03,
            "joy": 0.01, "sadness": 0.15,
        })
        self.assertEqual(emotion_detector("That is disgusting.")["dominant_emotion"], "disgust")

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_fear(self, mock_post):
        """Fear should be selected when it has the highest score."""
        mock_post.return_value = self._response({
            "anger": 0.11, "disgust": 0.07, "fear": 0.70,
            "joy": 0.01, "sadness": 0.11,
        })
        self.assertEqual(emotion_detector("I am afraid.")["dominant_emotion"], "fear")

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_sadness(self, mock_post):
        """Sadness should be selected when it has the highest score."""
        mock_post.return_value = self._response({
            "anger": 0.11, "disgust": 0.07, "fear": 0.10,
            "joy": 0.01, "sadness": 0.71,
        })
        self.assertEqual(emotion_detector("This makes me sad.")["dominant_emotion"], "sadness")

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_empty_text_does_not_call_api(self, mock_post):
        """Empty input should return six None values without an HTTP call."""
        self.assertEqual(emotion_detector("  "), {
            "anger": None, "disgust": None, "fear": None,
            "joy": None, "sadness": None, "dominant_emotion": None,
        })
        mock_post.assert_not_called()

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_http_400(self, mock_post):
        """Watson HTTP 400 should produce all None values rather than crash."""
        mock_post.return_value.status_code = 400
        result = emotion_detector("invalid")
        self.assertIsNone(result["dominant_emotion"])
        self.assertEqual(len(result), 6)

    @patch("EmotionDetection.emotion_detection.requests.post")
    def test_service_error(self, mock_post):
        """A connection problem should remain visible to the calling app."""
        mock_post.side_effect = requests.ConnectionError("service offline")
        with self.assertRaises(requests.RequestException):
            emotion_detector("Hello")

    @staticmethod
    def _response(emotions):
        """Construct a realistic successful Watson response mock."""
        response = Mock(status_code=200)
        response.json.return_value = {
            "emotionPredictions": [{"emotion": emotions}]
        }
        response.raise_for_status.return_value = None
        return response


if __name__ == "__main__":
    unittest.main(verbosity=2)
