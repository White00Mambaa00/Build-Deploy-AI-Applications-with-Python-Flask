"""Analyze text emotions using the IBM Skills Network Watson NLP endpoint.

The endpoint is hosted by the course provider and needs internet access. It may
be unavailable outside the course environment. Unit tests mock the HTTP call,
so they can run without a live Watson service.
"""

import os

import requests

EMOTIONS = ("anger", "disgust", "fear", "joy", "sadness")
WATSON_URL = os.getenv(
    "WATSON_EMOTION_URL",
    "https://sn-watson-emotion.labs.skills.network/"
    "v1/watson.runtime.nlp.v1/NlpService/EmotionPredict",
)
HEADERS = {
    "grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"
}


def _empty_result():
    """Return the empty-score format expected for invalid input."""
    return {
        "anger": None,
        "disgust": None,
        "fear": None,
        "joy": None,
        "sadness": None,
        "dominant_emotion": None,
    }


def emotion_detector(text_to_analyze):
    """Return five emotion scores and the strongest emotion for given text.

    Blank text and HTTP 400 errors return a six-key dictionary of None values.
    Network/service failures raise requests exceptions so callers can display
    an appropriate error rather than reporting invented emotion scores.
    """
    if not isinstance(text_to_analyze, str) or not text_to_analyze.strip():
        return _empty_result()

    response = requests.post(
        WATSON_URL,
        headers=HEADERS,
        json={"raw_document": {"text": text_to_analyze}},
        timeout=20,
    )

    if response.status_code == 400:
        return _empty_result()

    response.raise_for_status()
    prediction = response.json()["emotionPredictions"][0]["emotion"]
    scores = {name: float(prediction[name]) for name in EMOTIONS}
    dominant_emotion = max(scores, key=scores.get)
    return {**scores, "dominant_emotion": dominant_emotion}
