"""Public interface for the IBM Watson NLP emotion detection package."""

from .emotion_detection import emotion_detector

__all__ = ["emotion_detector"]
