# IBM Emotion Detection — Coursera Final Project

Flask app that sends text to the IBM Skills Network Watson NLP EmotionPredict endpoint, formats the five emotion scores, and handles invalid inputs.

## Original repository

The course starter repository is: https://github.com/ibm-developer-skills-network/oaqjp-final-project-emb-ai

This ZIP is a **standalone implementation** intended to help you complete the tasks. If you are required to clone/fork the course's repository, do that first and transfer the completed Python files into your own clone. Preserve any course starter files if your lab instructions require them. Do not claim you cloned the course repository unless you actually did.

## Setup (Linux/macOS, Python 3.9+)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v test_emotion_detection
python server.py
```

Open http://127.0.0.1:5000 and enter a sentence. Stop the app using Ctrl+C.

On Windows use `py -m venv .venv` then `.venv\\Scripts\\activate` and `py -m pip install -r requirements.txt`.

## Watson service

An internet connection and access to the course's Watson NLP endpoint are needed to obtain real emotion results. The service URL currently used is:

`https://sn-watson-emotion.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/EmotionPredict`

You can override it with environment variable `WATSON_EMOTION_URL` if the course supplies an updated URL. This ZIP cannot guarantee that IBM's hosted course service is reachable from your network. Unit tests simulate (mock) its responses; passing tests **does not** prove the live service is reachable.

## Helpful verification commands

```bash
# Task 1: inspect folders
find . -maxdepth 3 -type f -not -path './.venv/*' | sort

# Task 2/3: shell test with the real service
python -c 'from EmotionDetection import emotion_detector; print(emotion_detector("I am very happy today"))'

# Task 4: package-level import
python -c 'from EmotionDetection import emotion_detector; print(emotion_detector(""))'

# Task 5: offline unit tests that mock the external HTTP requests
python -m unittest -v test_emotion_detection

# Task 8: static analysis
pylint server.py
```

The test suite uses Python's standard `unittest` with `unittest.mock` to avoid making real API requests. It verifies all five emotions, JSON payload, HTTP 400, and network failure.

## Expected behaviour

- Successful real Watson response: returns anger, disgust, fear, joy, sadness and the highest (dominant) emotion.
- Blank input or Watson HTTP 400: `None` values for all six fields; web view displays `Invalid text! Please try again!`.
- Network/service failure: web app displays a clear 503 error instead of mislabeling the emotion.
- Flask route `/emotionDetector?textToAnalyze=...` is used by the browser UI.

## Evidence / screenshots

**Capture screenshots of your own code, running commands, and actual web interface. Do not submit mockups or renamed screenshots from this package as evidence of work you haven't run.**

See `SUBMISSION_SCREENSHOT_GUIDE.md` for the 16 filenames and what each should show.

## Notes

- Flask local deployment at 127.0.0.1:5000 does **not** mean public hosting on the internet.
- If `pip` is unavailable in your restricted lab environment, use the provided course Cloud IDE or a permitted virtual environment. Do not install system packages without permission.
- Static analysis scores depend on your Pylint version and local configuration.
