# Submission guide — exact 16 filenames

Your screenshots show a **16-point peer-graded assignment**. Use the exact filenames below. For each image, open the file/code, terminal or browser on *your computer* and capture it (e.g. `PrtSc` or built-in screenshot). Save as PNG. The sample commands assume you are inside the project root and have installed dependencies.

## Task 1 — 1 point

- `1_folder_structure.png`: your project folder structure visible in a file explorer or terminal (`find . -maxdepth 3 -type f -not -path './.venv/*' | sort`). For this task, actually fork/clone the course repository if the course instructions require it.

## Task 2 — 2 points

- `2a_emotion_detection.png`: `EmotionDetection/emotion_detection.py`, showing the `emotion_detector()` function, endpoint, request, JSON parsing.
- `2b_application_creation.png`: successful Python shell import and live call, e.g. `from EmotionDetection import emotion_detector` and `emotion_detector('I am very happy today')`. Only show real output from a live successful call; if course service is unavailable, get access through the lab.

## Task 3 — 2 points

- `3a_output_formatting.png`: code showing the six-key output dictionary and `dominant_emotion` extraction in `emotion_detection.py`.
- `3b_formatted_output_test.png`: terminal showing the returned dictionary with anger/disgust/fear/joy/sadness/dominant_emotion.

## Task 4 — 2 points

- `4a_packaging.png`: `EmotionDetection/` folder showing `__init__.py` and `emotion_detection.py`, and the contents of `__init__.py`.
- `4b_packaging_test.png`: terminal import from package and successful call, e.g. `from EmotionDetection import emotion_detector`.

## Task 5 — 2 points

- `5a_unit_testing.png`: `test_emotion_detection.py` showing the unittest test cases.
- `5b_unit_testing_result.png`: terminal output of `python -m unittest -v test_emotion_detection`, with all tests passing.

## Task 6 — 2 points

- `6a_server.png`: open `server.py` in editor showing Flask imports, routes and app launch.
- `6b_deployment_test.png`: browser showing `http://127.0.0.1:5000/` and ideally a successful analysis of sample text, using the working real Watson service.

## Task 7 — 3 points

- `7a_error_handling_function.png`: `emotion_detection.py` code showing handling of HTTP status 400 and empty input.
- `7b_error_handling_server.png`: `server.py` code handling returned `None` and showing `Invalid text! Please try again!`.
- `7c_error_handling_interface.png`: browser UI after empty or invalid input, displaying `Invalid text! Please try again!`. In this sample UI a blank textarea is validated by HTML; to test backend logic directly you can visit `http://127.0.0.1:5000/emotionDetector?textToAnalyze=` (backend emits the exact error string). To show it *inside* the UI, enter spaces in the textarea and click Analyze.

## Task 8 — 2 points

- `8a_server_modified.png`: complete/refactored `server.py` with module/function docstrings and final changes.
- `8b_static_code_analysis.png`: terminal output of `pylint server.py` showing 10.00/10 if that is what your environment produces. If not, address the actual warnings, then rerun and capture the real output.

## Submission checklist

1. Title suggestion: `Emotion Detection Application Using IBM Watson NLP and Flask`.
2. Verify the filename on **each** screenshot and that each shows the required evidence legibly.
3. Upload each PNG to the corresponding assignment field. The project ZIP is not a substitute for the requested screenshots.
4. Never submit fabricated passing API responses or pretend that live calls worked if the endpoint is inaccessible.
