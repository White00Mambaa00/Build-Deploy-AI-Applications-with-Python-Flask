"use strict";

const form = document.getElementById("emotion-form");
const result = document.getElementById("system_response");
const button = document.getElementById("analyze-button");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = document.getElementById("textToAnalyze").value;
  if (!text.trim()) {
    result.textContent = "Invalid text! Please try again!";
    return;
  }

  button.disabled = true;
  result.textContent = "Analyzing your sentence...";
  try {
    const response = await fetch(`/emotionDetector?textToAnalyze=${encodeURIComponent(text)}`);
    const message = await response.text();
    result.textContent = message || "No response received.";
  } catch (error) {
    result.textContent = "Could not connect to the application. Please try again.";
  } finally {
    button.disabled = false;
  }
});
