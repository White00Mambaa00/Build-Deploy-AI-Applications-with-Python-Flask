"""Demonstrate formatted output with a mocked Watson HTTP response (not a live call)."""
from unittest.mock import Mock, patch
from pprint import pprint
from EmotionDetection import emotion_detector

mock = Mock(status_code=200)
mock.json.return_value = {
    'emotionPredictions': [{'emotion': {
        'anger': 0.02, 'disgust': 0.01, 'fear': 0.03,
        'joy': 0.91, 'sadness': 0.03,
    }}]
}
mock.raise_for_status.return_value = None
with patch('EmotionDetection.emotion_detection.requests.post', return_value=mock):
    prediction = emotion_detector('I am very happy today')
print('MODE: OFFLINE TEST — Watson HTTP response mocked (NOT LIVE)')
print('INPUT: I am very happy today')
pprint(prediction, sort_dicts=False)
